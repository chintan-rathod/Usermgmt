﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using AutoMapper;
using FluentValidation;
using MediatR;
using UserManagement.Domain.Entities;
using UserManagement.Domain.Models;
using UserMgmt.DataAccess;
namespace UserMgmt.Logic
{
   public class SingleUserRequest : IRequest<UserDTO>
    {
        public string ID { get; }

        public SingleUserRequest(string id)
        {
            ID = id;
        }
    }

    public class SingleUserRequestHandler : IRequestHandler<SingleUserRequest, UserDTO>
    {
        private readonly IMapper _mapper;
        private readonly iUserDao _userdao;
        public SingleUserRequestHandler(IMapper mapper, iUserDao userdao)
        {
            _mapper = mapper;
            _userdao = userdao;
        }

        public async Task<UserDTO> Handle(SingleUserRequest request, CancellationToken cancellationToken)
        {
            
            var returnUser = _userdao.Get(request.ID);
            var userdto = _mapper.Map<UserDTO>(returnUser);
            return await Task.FromResult(userdto);

        }
    }
    
}
