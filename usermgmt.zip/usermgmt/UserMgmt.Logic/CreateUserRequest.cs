﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using AutoMapper;
using FluentValidation;
using MediatR;
using UserManagement.Domain.Entities;
using UserManagement.Domain.Models;
using UserMgmt.DataAccess;

namespace UserMgmt.Logic
{
    public class CreateUserRequest : IRequest<UserDTO>
    {

        public UserDTO DTO { get; }

        public CreateUserRequest(UserDTO dto)
        {
            DTO = dto;
        }
    }
    public class CreateUserRequestHandler : IRequestHandler<CreateUserRequest, UserDTO>
    {
        private readonly IMapper _mapper;
        private readonly iUserDao _userdao;
        public CreateUserRequestHandler(IMapper mapper, iUserDao userdao)
        {
            _mapper = mapper;
            _userdao = userdao;
        }

        public async Task<UserDTO> Handle(CreateUserRequest request, CancellationToken cancellationToken)
        {
            var user = _mapper.Map<User>(request.DTO);
            var returnUser = _userdao.Create(user);
            var userdto = _mapper.Map<UserDTO>(returnUser);
            return await Task.FromResult(userdto);

        }
    }
    public class CreateUserRequestValidator : AbstractValidator<UserDTO>
    {
        public CreateUserRequestValidator()
        {


            RuleFor(x => x.FirstName)
                .NotNull()
                .WithMessage("The first name must not be null or empty.");
            RuleFor(x => x.FirstName)
               .NotEmpty()
               .WithMessage("The first name must not be null or empty.");
            RuleFor(x => x.FirstName)
                 .NotNull().MaximumLength(50).
                WithMessage("Maximum length should be 50 character.");
            RuleFor(x => x.FirstName)
               .NotNull().Matches(@"^[a-zA-Z-']*$").
              WithMessage("First name should not contain special character or number.");

            RuleFor(x => x.LastName)
              .NotNull()
              .WithMessage("The last name must not be null or empty.");
            RuleFor(x => x.LastName)
            .NotEmpty()
            .WithMessage("The last name must not be null or empty.");
            RuleFor(x => x.LastName)
                 .NotNull().MaximumLength(50).
                WithMessage("Maximum length of last nameshould be 50 character.");
            RuleFor(x => x.LastName)
               .NotNull().Matches(@"^[a-zA-Z-']*$").
              WithMessage("Last name should not contain special character or number.");


            RuleFor(x => x.UserName)
             .NotNull()
             .WithMessage("The UserName must not be null or empty.");
            RuleFor(x => x.UserName)
            .NotEmpty()
            .WithMessage("The UserName must not be null or empty.");

            RuleFor(x => x.UserName)
           .NotNull().MaximumLength(25)
           .WithMessage("Maximum length of username should be 25 character.");

            RuleFor(x => x.Password)
             .NotNull()
             .WithMessage("The password must not be null or empty.");
            RuleFor(x => x.Password)
           .NotEmpty()
           .WithMessage("The password must not be null or empty.");

            RuleFor(x => x.Password)
            .NotNull().Matches(@"^.*(?=.{6,})(?=.*\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[!*@#$%^&+=]).*$")
            .WithMessage("Invalid password-1 special Character ,1 Caps , 1 lowercase");

            RuleFor(x => x.Password)
            .NotNull().MinimumLength(6)
            .WithMessage("Minimum length of password should be 6 character.");

            RuleFor(x => x.MobileNumber)
            .NotNull()
            .WithMessage("Mobile number should be 10 digit.");

            RuleFor(x => x.MobileNumber)
            .NotEmpty()
            .WithMessage("Mobile number should be 10 digit.");

            RuleFor(x => x.MobileNumber)
             .NotNull().MaximumLength(10)
             .WithMessage("Mobile number should be 10 digit.");

            RuleFor(x => x.MobileNumber)
            .NotNull().MinimumLength(10)
            .WithMessage("Mobile number should be 10 digit.");

            RuleFor(s => s.BirthDate).
         NotNull()
         .WithMessage("Birth Date should not be empty or null");

            RuleFor(s => s.BirthDate).
       NotEmpty()
       .WithMessage("Birth Date should not be empty or null");

            RuleFor(s => s.BirthDate)
         .Must(BeAValidDate)
         .WithMessage("Invalid Birth date.");

            RuleFor(s => s.BirthDate)
           .Must(BeAValidDate)
           .WithMessage("Invalid Birth date.");
        }


        private bool BeAValidDate(string value)
        {
            DateTime date;
            return DateTime.TryParse(value, out date);
        }
    }
}
