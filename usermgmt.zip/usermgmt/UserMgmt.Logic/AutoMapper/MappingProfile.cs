﻿using System;
using System.Collections.Generic;
using System.Text;
using AutoMapper;
using UserManagement.Domain.Entities;
using UserManagement.Domain.Models;
namespace UserMgmt.Logic.AutoMapper
{
   public class MappingProfile : Profile
    {

        public MappingProfile()
        {
            CreateMap<UserDTO, User>();
            CreateMap<User, UserDTO>();


        }
    }
}
