﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using AutoMapper;
using FluentValidation;
using MediatR;
using UserManagement.Domain.Entities;
using UserManagement.Domain.Models;
using UserMgmt.DataAccess;

namespace UserMgmt.Logic
{
   public class UserListRequest  : IRequest<List<UserDTO>> 
    {

        public UserListRequest()
        {
          
        }
    }

    public class UserListRequestHandler : IRequestHandler<UserListRequest, List<UserDTO>>
    {
        private readonly IMapper _mapper;
        private readonly iUserDao _userdao;
        public UserListRequestHandler(IMapper mapper, iUserDao userdao)
        {
            _mapper = mapper;
            _userdao = userdao;
        }

        public async Task<List<UserDTO>> Handle(UserListRequest request, CancellationToken cancellationToken)
        {

            var returnUser = _userdao.Get();
            var userdto = _mapper.Map<List<UserDTO>>(returnUser);
            return await Task.FromResult(userdto);

        }
    }
}
