﻿using System;
using System.Collections.Generic;
using System.Text;

namespace UserManagement.Domain.Models
{
   public class UserstoreDatabaseSettings: IUserstoreDatabaseSettings
    {
        
        public virtual string ConnectionString { get; set; }
        public virtual string DatabaseName { get; set; }
    }

    public interface IUserstoreDatabaseSettings
    {
 
        string ConnectionString { get; set; }
        string DatabaseName { get; set; }
    }
}
