﻿using MongoDB.Driver;
using System;
using System.Collections.Generic;
using System.Text;
using UserManagement.Domain.Entities;
using UserManagement.Domain.Models;

namespace UserMgmt.DataAccess
{
    public class UserDao : iUserDao
    {

        private readonly IMongoCollection<User> _users;
        //comment 
        public UserDao(IUserstoreDatabaseSettings settings)
        {
            var client = new MongoClient(settings?.ConnectionString);
            var database = client.GetDatabase(settings?.DatabaseName);

            _users = database.GetCollection<User>("Users");
        }


        public List<User> Get() =>

        _users.Find(book => true).ToList();

        public User Get(string id) =>
            _users.Find<User>(u => u.Id == id).FirstOrDefault();

        public virtual User Create(User user)
        {
            _users.InsertOne(user);
            return user;
        }

    }

    public interface iUserDao
    {
        List<User> Get();
        User Create(User user);
        User Get(string id);


    }
}
