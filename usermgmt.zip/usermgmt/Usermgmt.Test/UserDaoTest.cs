﻿using FakeItEasy;
using FluentAssertions;
using System;
using System.Collections.Generic;
using System.Text;
using UserManagement.Domain.Entities;
using UserManagement.Domain.Models;
using UserMgmt.DataAccess;
using Xunit;

namespace Usermgmt.Test
{
   public class UserDaoTest
    {

        private readonly UserDao _userDaoFake;
        private readonly User _newuser;
        private UserstoreDatabaseSettings setting;

        public   UserDaoTest()
        {

            setting = A.Fake<UserstoreDatabaseSettings>();
            setting.DatabaseName = "UserDb";
            setting.ConnectionString = "mongodb://localhost:27017";
          //  _userDaoFake = new UserDao (setting);

            _userDaoFake = A.Fake<UserDao>(x => x.WithArgumentsForConstructor(new object[] { setting }));
            // _testee = new Repository<Customer>(Context);
            _newuser = new User()
            {
                FirstName = "samir",
                LastName = "rathod",
                Gender = 'M',
                Location = "Kochi",
                MobileNumber = "9879852637",
                Password = "Abc@123",
                UserName = "samirrathod",
                BirthDate = "11/06/1985"
            };

        }


        [Fact]
        public   void CreateUserAsync_WhenCustomerIsNotNull_ShouldReturnUser()
        {
            A.CallTo(() => _userDaoFake.Create(A<User>._)).Returns(_newuser);
            var result =   _userDaoFake.Create(_newuser);
            result.Should().BeOfType<User>();
            result.FirstName.Should().Be("chintan");
        }


        [Fact]
        public void CreateUserAsync_WhenCustomerCheckValue_ShouldReturnUser()
        {
            A.CallTo(() => _userDaoFake.Create(A<User>._)).Returns(_newuser);
            var result = _userDaoFake.Create(_newuser);
            result.FirstName.Should().Be("samir");
            result.LastName.Should().Be("rathod");
            result.Location.Should().Be("Kochi");
            result.MobileNumber.Should().Be("9879852637");
            result.UserName.Should().Be("samirrathod");
            result.BirthDate.Should().Be("11/06/1985");
        }
    }
}
