﻿using AutoMapper;
using FakeItEasy;
using FluentAssertions;
using UserManagement.Domain.Entities;
using UserManagement.Domain.Models;
using UserMgmt.DataAccess;
using UserMgmt.Logic;
using UserMgmt.Logic.AutoMapper;
using Xunit;

namespace Usermgmt.Test
{
  public  class CreateUserRequestHandlerTest
    {
        private readonly CreateUserRequestHandler _requestHandler;

        private readonly iUserDao _repository;
        private readonly IMapper _mapper;

        private readonly IUserstoreDatabaseSettings setting;
        public CreateUserRequestHandlerTest()
        {
            setting = new UserstoreDatabaseSettings();
            setting.DatabaseName = "UserDb"; 
            setting.ConnectionString = "mongodb://localhost:27017";
            _repository = A.Fake<UserDao>(x => x.WithArgumentsForConstructor(  new object[] { setting }));

            var mockMapper = new MapperConfiguration(cfg =>
            {
                cfg.AddProfile(new MappingProfile());
            });
            _mapper = mockMapper.CreateMapper();

            _requestHandler = new CreateUserRequestHandler(_mapper,_repository);
        }


        [Fact]
        public async void Handle_ShouldReturnCreatedUser()
        {
           
            A.CallTo(() => _repository.Create(A<User>._)).Returns(new User
            {
                FirstName = "chintan"
            });

            var result = await _requestHandler.Handle(new CreateUserRequest(new UserDTO
            {
                FirstName = "chintan"
            }), default);

            result.Should().BeOfType<UserDTO>();
            result.FirstName.Should().Be("chintan");
        }
    }
}
