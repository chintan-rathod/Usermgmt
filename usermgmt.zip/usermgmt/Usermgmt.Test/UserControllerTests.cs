using AutoMapper;
using FakeItEasy;
using FluentAssertions;
using MediatR;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Net;
using UserManagement.Controllers;
using UserManagement.Domain.Models;
using UserMgmt.Logic;
using Xunit;


namespace Usermgmt.Test
{
    public class UserControllerTests
    {

        private readonly IMediator _mediator;
        private readonly UserController _userController;
        private readonly UserDTO _userDto;
        private readonly string _id = "5f250e23041e91b81c43dce8";
        List<UserDTO> lstReturnResult;
        public UserControllerTests()
        {

            var mapper = A.Fake<IMapper>();

            _mediator = A.Fake<IMediator>();
            _userController = new UserController(_mediator);
            _userDto = new UserDTO()
            {
                FirstName = "samir",
                LastName = "rathod",
                Gender = 'M',
                Location = "Kochi",
                MobileNumber = "9879852637",
                Password = "Abc@123",
                UserName = "samirrathod",
                BirthDate = "11/06/1985"


            };

            var returnUser = new UserDTO
            {
                Id = _id,
                FirstName = "samir",
                LastName = "rathod",
                Gender = 'M',
                Location = "Kochi",
                MobileNumber = "9879852637",
                Password = "Abc@123",
                UserName = "samirrathod",
                BirthDate = "11/06/1985"
            };
            var returnUser1 = new UserDTO
            {
                Id = _id,
                FirstName = "janak",
                LastName = "rathod",
                Gender = 'M',
                Location = "Bangalore",
                MobileNumber = "9879852637",
                Password = "Abc@123",
                UserName = "samirrathod",
                BirthDate = "11/06/1985"
            };
            lstReturnResult = new List<UserDTO>();
            lstReturnResult.Add(returnUser);
            lstReturnResult.Add(returnUser1);

            A.CallTo(() => mapper.Map<UserDTO>(A<UserDTO>._)).Returns(returnUser);
            A.CallTo(() => _mediator.Send(A<CreateUserRequest>._, default)).Returns(returnUser);
            A.CallTo(() => _mediator.Send(A<SingleUserRequest>._, default)).Returns(returnUser);
            A.CallTo(() => _mediator.Send(A<UserListRequest>._, default)).Returns(lstReturnResult);


        }

        [Fact]
        public async void Post_ShouldReturnUser()
        {
            var result = await _userController.Create(_userDto);
             (result.Result as Microsoft.AspNetCore.Mvc.StatusCodeResult)?.StatusCode.Should().Be((int)HttpStatusCode.OK);
            result.Value.Should().BeOfType<UserDTO>();
            result.Value.Id.Should().Be(_id); 

        }
        [Theory]
        [InlineData("CreateUserAsync: User is null")]
        public async void Post_WhenAnExceptionOccurs_ShouldReturnBadRequest(string exceptionMessage)
        {
            A.CallTo(() => _mediator.Send(A<CreateUserRequest>._, default)).Throws(new ArgumentException(exceptionMessage));

            var result = await _userController.Create(_userDto);

            (result.Result as StatusCodeResult)?.StatusCode.Should().Be((int)HttpStatusCode.BadRequest);
            (result.Result as BadRequestObjectResult)?.Value.Should().Be(exceptionMessage);
        }

        [Fact]
        public async void GetAllUsers()
        {
            var result = await _userController.Get();
            (result.Result as Microsoft.AspNetCore.Mvc.StatusCodeResult)?.StatusCode.Should().Be((int)HttpStatusCode.OK);
            result.Value.Should().BeOfType<List<UserDTO>>();
            result.Value.Count.Should().Be(2);

        }


        [Fact]
        public async void GetAllUsersIfNoResult()
        {
            A.CallTo(() => _mediator.Send(A<UserListRequest>._, default)).Returns(new List<UserDTO>());
            var result = await _userController.Get();
            (result.Result as Microsoft.AspNetCore.Mvc.StatusCodeResult)?.StatusCode.Should().Be((int)HttpStatusCode.NotFound);
            result.Value.Should().BeOfType<List<UserDTO>>();
            result.Value.Count.Should().Be(0);

        }

        [Fact]
        public async void GetSingleUsersIfNoResult()
        {
            A.CallTo(() => _mediator.Send(A<UserListRequest>._, default)).Returns(new List<UserDTO>());
            var result = await _userController.Get();
            (result.Result as Microsoft.AspNetCore.Mvc.StatusCodeResult)?.StatusCode.Should().Be((int)HttpStatusCode.OK);
            result.Value.Should().BeOfType<List<UserDTO>>();
            result.Value.Count.Should().Be(0);

        }

        [Fact]
        public async void GetSingleUsers()
        {
            var result = await _userController.Get(_id);
            (result.Result as Microsoft.AspNetCore.Mvc.StatusCodeResult)?.StatusCode.Should().Be((int)HttpStatusCode.OK);
            result.Value.Should().BeOfType<UserDTO>();
            result.Value.Id.Should().Be(_id);

        }
         

    }
}
