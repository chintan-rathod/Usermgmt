﻿using System;
using FluentValidation.TestHelper;
using UserMgmt.Logic;
using Xunit;

namespace Usermgmt.Test
{

   
    public  class CreateUserModelValidatorTests
    {
        private readonly CreateUserRequestValidator validator;

        public CreateUserModelValidatorTests()
        {
            validator = new CreateUserRequestValidator();
        }

        // First name Test case
        [Theory]
        [InlineData("")]
        [InlineData(null)]
        public void FirstName_NullOrEmpty_ShouldHaveValidationError(string firstName)
        {
            validator.ShouldHaveValidationErrorFor(x => x.FirstName, firstName).WithErrorMessage("The first name must not be null or empty.");
        }


        [Theory]
        [InlineData("abcdegghijklmnopqrstuvwxyxabcdegghijklmnopqrstuvwxyx")]
        public void FirstName_GreaterThan50_ShouldHaveValidationError(string firstName)
        {
            validator.ShouldHaveValidationErrorFor(x => x.FirstName, firstName).WithErrorMessage("Maximum length should be 50 character.");
        }

        [Theory]
        [InlineData("abc@123")]
        public void FirstName_SpecialCharacter_ShouldHaveValidationError(string firstName)
        {
            validator.ShouldHaveValidationErrorFor(x => x.FirstName, firstName).WithErrorMessage("First name should not contain special character or number.");
        }



        // Last name Test case

        [Theory]
        [InlineData("")]
        [InlineData(null)]
        public void LastName_NullOrEmpty_ShouldHaveValidationError(string lastName)
        {
            validator.ShouldHaveValidationErrorFor(x => x.LastName, lastName).WithErrorMessage("The Last name must not be null or empty.");
        }
        [Theory]
        [InlineData("abcdegghijklmnopqrstuvwxyxabcdegghijklmnopqrstuvwxyx")]
        public void LastName_GreaterThan50_ShouldHaveValidationError(string lastName)
        {
            validator.ShouldHaveValidationErrorFor(x => x.LastName, lastName).WithErrorMessage("Maximum length should be 50 character.");
        }
        [Theory]
        [InlineData("abc@123")]
        public void LastName_SpecialCharacter_ShouldHaveValidationError(string lastName)
        {
            validator.ShouldHaveValidationErrorFor(x => x.LastName, lastName).WithErrorMessage("Last name should not contain special character or number.");
        }

        //User Name test case

        [Theory]
        [InlineData("")]
        [InlineData(null)]
        public void UserName_NullOrEmpty_ShouldHaveValidationError(string userName)
        {
            validator.ShouldHaveValidationErrorFor(x => x.UserName, userName).WithErrorMessage("The UserName must not be null or empty.");
        }
        [Theory]
        [InlineData("abcdegghijklmnopqrstuvwxyxabcdegghijklmnopqrstuvwxyx")]
        public void UserName_GreaterThan25_ShouldHaveValidationError(string userName)
        {
            validator.ShouldHaveValidationErrorFor(x => x.UserName, userName).WithErrorMessage("Maximum length of username should be 25 character.");
        }

        //Password Validation test 
        [Theory]
        [InlineData("")]
        [InlineData(null)]
        public void Password_NullOrEmpty_ShouldHaveValidationError(string password)
        {
            validator.ShouldHaveValidationErrorFor(x => x.Password, password).WithErrorMessage("The password must not be null or empty.");
        }


        [Theory]
        [InlineData("abc")]
        public void Password_GreaterThan6_ShouldHaveValidationError(string password)
        {
            validator.ShouldHaveValidationErrorFor(x => x.Password, password).WithErrorMessage("Minimum length of password should be 6 character.");
        }


        [Theory]
        [InlineData("abc")]
        [InlineData("abc123")]
        [InlineData("abc@@$%")]
        [InlineData("ABCDFFT")]
        [InlineData("@#!@##$%#$%")]
        public void Password_ValidScenrio_ShouldHaveValidationError(string password)
        {
            validator.ShouldHaveValidationErrorFor(x => x.Password, password).WithErrorMessage("Invalid password-1 special Character ,1 Caps , 1 lowercase");
        }

        // mobile number validation
        [Theory]
        [InlineData("")]
        [InlineData(null)]
        public void MobileNumber_GreaterThan6_ShouldHaveValidationError(string moNumber)
        {
            validator.ShouldHaveValidationErrorFor(x => x.MobileNumber, moNumber).WithErrorMessage("Mobile number should be 10 digit.");
        }

        [Theory]
        [InlineData("9987")]
        [InlineData("987958796366")]
        public void MobileNumber_MinMax_ShouldHaveValidationError(string moNumber)
        {
            validator.ShouldHaveValidationErrorFor(x => x.MobileNumber, moNumber).WithErrorMessage("Mobile number should be 10 digit.");
        }


        //Birth date validation test case

        [Theory]
        [InlineData("")]
        [InlineData(null)]
        public void BirthDate_EmptyorNull_ShouldHaveValidationError(string birthDate)
        {
            validator.ShouldHaveValidationErrorFor(x => x.BirthDate, birthDate).WithErrorMessage("Birth Date should not be empty or null");
        }

        [Theory]
        [InlineData("chintan")]
        [InlineData("987958796366")]
        [InlineData("52/25/1200")]
        public void BirthDate_Valid_ShouldHaveValidationError(string birthDate)
        {
            validator.ShouldHaveValidationErrorFor(x => x.BirthDate, birthDate).WithErrorMessage("Invalid Birth date.");
        }

    }



}
