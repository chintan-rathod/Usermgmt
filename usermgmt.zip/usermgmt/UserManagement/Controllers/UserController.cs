﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using MediatR;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using UserManagement.Domain.Models;
using UserMgmt.Logic;

namespace UserManagement.Controllers
{
    [Route("api/user")]
    [ApiController]
    public class UserController : ControllerBase
    {

        private readonly IMediator _mediator;

        public UserController(IMediator mediator)
        {
            _mediator = mediator;
        }

        [HttpGet]
        public async Task<ActionResult<List<UserDTO>>> Get()
        {

           
            try
            {
                var result = await _mediator.Send(new UserListRequest());
                if (result == null)
                    return NoContent();
                return  result;
            }
            catch (Exception ex)
            {
                return StatusCode(500, ex.Message);
            }
        }
        [HttpGet]
        [Route("{userID}")]
        public async Task<ActionResult<UserDTO>>  Get(string userID)
        {
            
            
            if(userID==null ||  userID.Length<24 )
            {
                return BadRequest("Please Provide proper UserID");
            }
            try
            {
                var result = await _mediator.Send(new SingleUserRequest(userID));
                if (result == null)
                    return NoContent();
                return result;
            }
            catch (Exception ex)
            {
                return StatusCode(500, ex.Message);
            }
        }
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status422UnprocessableEntity)]
        [HttpPost]
        public async Task<ActionResult<UserDTO>> Create([FromBody] UserDTO dto)
        {
          


            try
            {
                var result = await _mediator.Send(new CreateUserRequest(dto));
              
                return result;
            }
            catch (Exception ex)
            {
                return StatusCode (500,ex.Message);
            }
        }
    }
}